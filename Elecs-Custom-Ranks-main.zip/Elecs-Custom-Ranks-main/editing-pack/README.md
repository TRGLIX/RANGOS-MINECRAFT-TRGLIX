# Welcome to the editing section!
This is where you can customize the default pack! <br>
For tutorials on how to do this, please visit these links!
## Java Version Customization + LuckPerms Customization
Watch [this detailed video](https://youtu.be/U12ve5kCDfQ?si=Vl3MFGdH3c5RcS87) on setting up your custom ranks for Java!
## Bedrock Version Customization
Watch [this detailed video]() on setting up your custom ranks for Bedrock!
